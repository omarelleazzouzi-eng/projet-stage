import { useState, useEffect } from 'react';
import api from '../api/axios';

export default function Evenements() {
  const [events, setEvents] = useState([]);
  const [clubs, setClubs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [formData, setFormData] = useState({
    titre: '', description: '', date_evenement: '', lieu: '', 
    categorie: '', max_participants: '', club_id: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [eventsRes, clubsRes] = await Promise.all([
        api.get('/events'),
        api.get('/clubs')
      ]);
      setEvents(eventsRes.data);
      setClubs(clubsRes.data);
    } catch (err) {
      console.error('Erreur:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedEvent) {
        await api.put(`/events/${selectedEvent}`, formData);
      } else {
        await api.post('/events', formData);
      }
      setShowForm(false);
      setSelectedEvent(null);
      setFormData({ titre: '', description: '', date_evenement: '', lieu: '', categorie: '', max_participants: '', club_id: '' });
      fetchData();
    } catch (err) {
      alert('Erreur lors de l\'enregistrement');
    }
  };

  const handleEdit = (event) => {
    setSelectedEvent(event.id);
    setFormData({
      titre: event.titre,
      description: event.description || '',
      date_evenement: event.date_evenement.slice(0, 16),
      lieu: event.lieu,
      categorie: event.categorie || '',
      max_participants: event.max_participants || '',
      club_id: event.club_id || ''
    });
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (confirm('Voulez-vous supprimer cet événement?')) {
      await api.delete(`/events/${id}`);
      fetchData();
    }
  };

  const formatDate = (date) => new Date(date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  if (loading) return <div className="p-8">Chargement...</div>;

  return (
    <div className="p-6">
      <div className="flex justify-between mb-6">
        <h1 className="text-2xl font-bold">Événements</h1>
        <button onClick={() => { setShowForm(!showForm); setSelectedEvent(null); setFormData({ titre: '', description: '', date_evenement: '', lieu: '', categorie: '', max_participants: '', club_id: '' }); }} className="bg-blue-600 text-white px-4 py-2 rounded">
          {showForm ? 'Annuler' : 'Nouvel événement'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded shadow mb-6">
          <h2 className="text-lg font-semibold mb-4">{selectedEvent ? 'Modifier' : 'Créer'} un événement</h2>
          <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
            <input placeholder="Titre" value={formData.titre} onChange={e => setFormData({...formData, titre: e.target.value})} className="border p-2 rounded col-span-2" required />
            <textarea placeholder="Description" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="border p-2 rounded col-span-2" rows="3" />
            <input type="datetime-local" value={formData.date_evenement} onChange={e => setFormData({...formData, date_evenement: e.target.value})} className="border p-2 rounded" required />
            <input placeholder="Lieu" value={formData.lieu} onChange={e => setFormData({...formData, lieu: e.target.value})} className="border p-2 rounded" required />
            <input placeholder="Catégorie" value={formData.categorie} onChange={e => setFormData({...formData, categorie: e.target.value})} className="border p-2 rounded" />
            <input type="number" placeholder="Nombre max participants" value={formData.max_participants} onChange={e => setFormData({...formData, max_participants: e.target.value})} className="border p-2 rounded" />
            <select value={formData.club_id} onChange={e => setFormData({...formData, club_id: e.target.value})} className="border p-2 rounded">
              <option value="">Aucun club</option>
              {clubs.map(c => <option key={c.id} value={c.id}>{c.nom}</option>)}
            </select>
            <button type="submit" className="bg-green-600 text-white p-2 rounded col-span-2">{selectedEvent ? 'Mettre à jour' : 'Créer'}</button>
          </form>
        </div>
      )}

      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 text-left">Titre</th>
              <th className="p-3 text-left">Date</th>
              <th className="p-3 text-left">Lieu</th>
              <th className="p-3 text-left">Club</th>
              <th className="p-3 text-center">Participants</th>
              <th className="p-3 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {events.map(event => (
              <tr key={event.id} className="border-b hover:bg-gray-50">
                <td className="p-3">
                  <div className="font-medium">{event.titre}</div>
                  <div className="text-sm text-gray-500">{event.categorie}</div>
                </td>
                <td className="p-3 text-sm">{formatDate(event.date_evenement)}</td>
                <td className="p-3">{event.lieu}</td>
                <td className="p-3">{event.club?.nom || '-'}</td>
                <td className="p-3 text-center">
                  {event.registrations?.filter(r => r.statut !== 'annule').length || 0}
                  {event.max_participants && ` / ${event.max_participants}`}
                </td>
                <td className="p-3 text-center space-x-2">
                  <button onClick={() => handleEdit(event)} className="text-blue-600 hover:underline">Modifier</button>
                  <button onClick={() => handleDelete(event.id)} className="text-red-600 hover:underline">Supprimer</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}