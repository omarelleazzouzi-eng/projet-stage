import { Link } from 'react-router-dom';

export default function Presentation() {
  const filieres = [
    {
      code: 'DWFS',
      nom: 'Développement Web et Full Stack',
      description: 'Formation complète aux technologies web modernes pour devenir développeur full stack.',
      modules: [
        'HTML5 & CSS3',
        'JavaScript & TypeScript',
        'React.js / Vue.js',
        'Node.js & Express',
        'PHP & Laravel',
        'Base de données (MySQL, MongoDB)',
        'Git & GitHub',
        'Méthodologie Agile'
      ],
      color: 'from-blue-500 to-indigo-600'
    },
    {
      code: 'PME',
      nom: 'Gestion des Petites et Moyennes Entreprises',
      description: 'Formation aux compétences management et gestion administrative des PME.',
      modules: [
        'Comptabilité générale',
        'Gestion financière',
        'Marketing digital',
        'Management',
        'Droit des affaires',
        'Logiciels de gestion',
        'Communication professionnelle',
        'Suivi clientele'
      ],
      color: 'from-green-500 to-teal-600'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-white/5 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">BTS</span>
            </div>
            <div>
              <h1 className="text-white text-xl font-bold">BTS Taza</h1>
              <p className="text-slate-400 text-sm">Centre de Formation Professionnelle</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Link to="/" className="px-4 py-2 text-white hover:text-blue-300">Accueil</Link>
            <Link to="/cours" className="px-4 py-2 text-white hover:text-blue-300">Cours</Link>
            <Link to="/evenements" className="px-4 py-2 text-white hover:text-blue-300">Événements</Link>
            <Link to="/login" className="px-4 py-2 text-white hover:text-blue-300">Connexion</Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            Bienvenue au BTS Taza
          </h1>
          <p className="text-xl text-slate-300 mb-8">
            Centre de Formation Professionnelle - Excellence pédagogique et formation d'avenir
          </p>
          <div className="flex justify-center gap-4">
            <Link to="/inscription" className="px-8 py-3 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-lg font-semibold hover:opacity-90">
              S'inscrire
            </Link>
            <Link to="/contact" className="px-8 py-3 border-2 border-white text-white rounded-lg font-semibold hover:bg-white/10">
              Nous contacter
            </Link>
          </div>
        </div>
      </section>

      {/* Objectifs */}
      <section className="py-16 px-4 bg-white/5">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-10">Nos Objectifs</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-white text-xl font-semibold mb-2">Formation de Qualité</h3>
              <p className="text-slate-300">Dispenser un enseignement professionnel de haut niveau</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">🚀</div>
              <h3 className="text-white text-xl font-semibold mb-2">Insertion Professionnelle</h3>
              <p className="text-slate-300">Préparer les étudiants au monde du travail</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">💡</div>
              <h3 className="text-white text-xl font-semibold mb-2">Innovation</h3>
              <p className="text-slate-300">Former aux nouvelles technologies et méthodes</p>
            </div>
          </div>
        </div>
      </section>

      {/* Filières */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-4">Nos Filières</h2>
          <p className="text-slate-300 text-center mb-10">Deux formations BTS reconnu au Maroc</p>
          
          <div className="grid md:grid-cols-2 gap-8">
            {filieres.map((filiere) => (
              <div key={filiere.code} className={`bg-gradient-to-br ${filiere.color} rounded-2xl p-8 text-white`}>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                    <span className="text-3xl font-bold">{filiere.code}</span>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold">{filiere.nom}</h3>
                    <p className="text-white/80">Code: {filiere.code}</p>
                  </div>
                </div>
                
                <p className="text-white/90 mb-6">{filiere.description}</p>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <h4 className="font-semibold mb-3">Modules étudiés:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {filiere.modules.map((module, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <span className="w-2 h-2 bg-white/60 rounded-full"></span>
                        <span>{module}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fonctionnement */}
      <section className="py-16 px-4 bg-white/5">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-10">Comment fonctionne la plateforme?</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-xl font-bold">1</div>
              <h3 className="text-white font-semibold mb-2">Inscription</h3>
              <p className="text-slate-300 text-sm">Créez votre compte étudiant</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-xl font-bold">2</div>
              <h3 className="text-white font-semibold mb-2">Validation</h3>
              <p className="text-slate-300 text-sm">Le directeur valide votre compte</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-xl font-bold">3</div>
              <h3 className="text-white font-semibold mb-2">Accès</h3>
              <p className="text-slate-300 text-sm">Accédez aux cours et événements</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-xl font-bold">4</div>
              <h3 className="text-white font-semibold mb-2">Suivi</h3>
              <p className="text-slate-300 text-sm"> Consultez vos absences en temps réel</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Une question?</h2>
          <p className="text-slate-300 mb-6">Contactez-nous pour plus d'informations sur nos formations</p>
          <Link to="/contact" className="inline-block px-6 py-3 bg-white text-slate-800 rounded-lg font-medium hover:bg-slate-100">
            Nous contacter
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/30 py-8 px-4">
        <div className="max-w-6xl mx-auto text-center text-slate-400">
          <p>© 2026 BTS Taza - Centre de Formation Professionnelle</p>
          <p className="text-sm mt-2">Route de Fès, Taza, Maroc</p>
        </div>
      </footer>
    </div>
  );
}