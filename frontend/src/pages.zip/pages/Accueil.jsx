import { Link } from 'react-router-dom';

export default function Accueil() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
              <span className="text-blue-800 font-bold text-xl">BTS</span>
            </div>
            <div>
              <h1 className="text-white text-xl font-bold">BTS Taza</h1>
              <p className="text-blue-200 text-sm">Centre de Formation</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Link to="/evenements" className="px-4 py-2 text-white hover:text-blue-200">Événements</Link>
            <Link to="/cours" className="px-4 py-2 text-white hover:text-blue-200">Cours</Link>
            <Link to="/contact" className="px-4 py-2 text-white hover:text-blue-200">Contact</Link>
            <Link to="/login" className="px-4 py-2 text-white hover:text-blue-200">Connexion</Link>
            <Link to="/inscription" className="px-4 py-2 bg-white text-blue-800 rounded-lg hover:bg-blue-50 font-medium">
              Inscription
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            Plateforme de Gestion des Absences
          </h1>
          <p className="text-xl text-blue-200 mb-8">
            BTS Taza - Centre de Formation Professionnelle
          </p>
          <div className="flex justify-center gap-4">
            <Link to="/inscription" className="px-8 py-3 bg-white text-blue-800 rounded-lg font-semibold hover:bg-blue-50">
              S'inscrire
            </Link>
            <Link to="/evenements" className="px-8 py-3 border-2 border-white text-white rounded-lg font-semibold hover:bg-white/10">
              Événements
            </Link>
            <Link to="/cours" className="px-8 py-3 border-2 border-white text-white rounded-lg font-semibold hover:bg-white/10">
              Cours
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-white/5">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
          <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
            <div className="text-4xl mb-4">📚</div>
            <h3 className="text-white text-xl font-semibold mb-2">Cours & Ressources</h3>
            <p className="text-blue-200">Accédez aux cours et ressources pédagogiques</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
            <div className="text-4xl mb-4">📊</div>
            <h3 className="text-white text-xl font-semibold mb-2">Suivi des Absences</h3>
            <p className="text-blue-200">Consultation de vos absences en temps réel</p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-center">
            <div className="text-4xl mb-4">👨‍🏫</div>
            <h3 className="text-white text-xl font-semibold mb-2">Espace Professor</h3>
            <p className="text-blue-200">Gestion des séances et des absences</p>
          </div>
        </div>
      </section>

      {/* Filières */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-10">Nos Filières BTS</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-6">
              <h3 className="text-white text-xl font-bold mb-2">DWFS</h3>
              <p className="text-blue-200">Développement Web et Full Stack</p>
              <p className="text-white/80 text-sm mt-2">Formation complète en développement web moderne</p>
            </div>
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-6">
              <h3 className="text-white text-xl font-bold mb-2">RSE</h3>
              <p className="text-blue-200">Réseaux et Systèmes Électroniques</p>
              <p className="text-white/80 text-sm mt-2">Formation en infrastructure réseau et électronique</p>
            </div>
            <div className="bg-gradient-to-r from-green-600 to-teal-600 rounded-xl p-6">
              <h3 className="text-white text-xl font-bold mb-2">GPME</h3>
              <p className="text-blue-200">Gestion des Petites et Moyennes Entreprises</p>
              <p className="text-white/80 text-sm mt-2">Formation en gestion d'entreprise</p>
            </div>
            <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-xl p-6">
              <h3 className="text-white text-xl font-bold mb-2">TRI</h3>
              <p className="text-blue-200">Technique des Réfrigération et Instrumentation</p>
              <p className="text-white/80 text-sm mt-2">Formation en froid et climatisation</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 px-4 bg-white/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Une question?</h2>
          <p className="text-blue-200 mb-6">Contactez-nous pour plus d'informations</p>
          <Link to="/contact" className="inline-block px-6 py-3 bg-white text-blue-800 rounded-lg font-medium hover:bg-blue-50">
            Nous contacter
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/20 py-8 px-4">
        <div className="max-w-6xl mx-auto text-center text-blue-300">
          <p>© 2026 BTS Taza - Centre de Formation Professionnelle</p>
          <p className="text-sm mt-2">Route de Fès, Taza, Maroc</p>
        </div>
      </footer>
    </div>
  );
}