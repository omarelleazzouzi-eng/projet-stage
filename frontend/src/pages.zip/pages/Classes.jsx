import { useState, useEffect } from 'react';
import api from '../api/axios';

export default function Classes() {
  const [classes, setClasses] = useState([]);
  const [professeurs, setProfesseurs] = useState([]);
  const [matieres, setMatieres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showImport, setShowImport] = useState(false);
  const [showAssign, setShowAssign] = useState(false);
  const [selectedClasse, setSelectedClasse] = useState(null);
  const [etudiants, setEtudiants] = useState([]);
  const [notification, setNotification] = useState(null);

  // Import state
  const [importProfessorId, setImportProfessorId] = useState('');
  const [importClasseId, setImportClasseId] = useState('');
  const [importMatiereId, setImportMatiereId] = useState('');
  const [importing, setImporting] = useState(false);
  const [importFile, setImportFile] = useState(null);

  // Assign state
  const [assignProfessorId, setAssignProfessorId] = useState('');
  const [assignMatiereId, setAssignMatiereId] = useState('');

  // Create class state
  const [showCreate, setShowCreate] = useState(false);
  const [newClass, setNewClass] = useState({ nom: '', code: '', filiere_id: '', niveau_id: '', annee_scolaire: new Date().getFullYear() });
  const [filieres, setFilieres] = useState([]);
  const [niveaux, setNiveaux] = useState([]);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [classesRes, profsRes, matieresRes, filieresRes, niveauxRes] = await Promise.all([
        api.get('/classes'),
        api.get('/professeurs'),
        api.get('/matieres'),
        api.get('/filieres'),
        api.get('/niveaux')
      ]);
      setClasses(classesRes.data);
      setProfesseurs(profsRes.data);
      setMatieres(matieresRes.data);
      setFilieres(filieresRes.data);
      setNiveaux(niveauxRes.data);
    } catch (err) {
      showNotification('Erreur chargement', 'error');
    } finally {
      setLoading(false);
    }
  };

  const showNotification = (message, type = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const selectClasse = async (classeId) => {
    if (selectedClasse === classeId) {
      setSelectedClasse(null);
      setEtudiants([]);
      return;
    }
    setSelectedClasse(classeId);
    try {
      const res = await api.get(`/classes/${classeId}/etudiants`);
      setEtudiants(res.data);
    } catch (err) {
      showNotification('Erreur chargement étudiants', 'error');
    }
  };

  // Filter classes based on selected professor
  const getFilteredClasses = () => {
    if (!importProfessorId) return classes;
    // For now, show all classes - in production, filter by professor's assigned classes
    return classes;
  };

  // Filter matieres based on selected professor
  const getFilteredMatieres = () => {
    if (!importProfessorId) return [];
    // Get matieres assigned to this professor
    const prof = professors.find(p => p.id === parseInt(importProfessorId));
    if (prof && prof.matieres) {
      return prof.matieres;
    }
    return matieres;
  };

  const handleImport = async (e) => {
    e.preventDefault();
    
    if (!importProfessorId || !importClasseId || !importMatiereId || !importFile) {
      showNotification('Veuillez remplir tous les champs obligatoires', 'error');
      return;
    }

    setImporting(true);
    const formData = new FormData();
    formData.append('file', importFile);
    formData.append('classe_id', importClasseId);

    try {
      // Import students
      const res = await api.post('/etudiants/import', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      // Assign professor+matiere to class
      await api.post('/classes/assign-professor-matiere', {
        classe_id: importClasseId,
        professor_id: importProfessorId,
        matiere_id: importMatiereId
      });

      showNotification(`Import réussi: ${res.data.imported} étudiant(s)`);
      setShowImport(false);
      resetImportForm();
      fetchData();
    } catch (err) {
      const msg = err.response?.data?.message || 'Erreur import';
      showNotification(msg, 'error');
    } finally {
      setImporting(false);
    }
  };

  const resetImportForm = () => {
    setImportProfessorId('');
    setImportClasseId('');
    setImportMatiereId('');
    setImportFile(null);
  };

  const handleAssign = async (classeId) => {
    if (!assignProfessorId || !assignMatiereId) {
      showNotification('Sélectionnez professeur et matière', 'error');
      return;
    }

    try {
      await api.post('/classes/assign-professor-matiere', {
        classe_id: classeId,
        professor_id: assignProfessorId,
        matiere_id: assignMatiereId
      });
      showNotification('Assignation créée');
      setShowAssign(false);
      setAssignProfessorId('');
      setAssignMatiereId('');
      fetchData();
    } catch (err) {
      showNotification('Erreur assignation', 'error');
    }
  };

  const handleCreateClass = async (e) => {
    e.preventDefault();
    if (!newClass.nom || !newClass.code || !newClass.filiere_id || !newClass.niveau_id) {
      showNotification('Veuillez remplir tous les champs', 'error');
      return;
    }

    setCreating(true);
    try {
      await api.post('/classes', {
        ...newClass,
        annee_scolaire: newClass.annee_scolaire || new Date().getFullYear()
      });
      showNotification('Classe créée avec succès!');
      setShowCreate(false);
      setNewClass({ nom: '', code: '', filiere_id: '', niveau_id: '', annee_scolaire: new Date().getFullYear() });
      fetchData();
    } catch (err) {
      showNotification(err.response?.data?.message || 'Erreur création classe', 'error');
    } finally {
      setCreating(false);
    }
  };

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
    </div>
  );

return (
    <div className="p-6 max-w-7xl mx-auto">
      {notification && (
        <div className={`fixed top-4 right-4 p-4 rounded-xl shadow-lg z-50 ${
          notification.type === 'error' ? 'bg-red-600' : 'bg-primary-600'
        } text-white`}>
          {notification.message}
        </div>
      )}

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-secondary-800">Gestion des Classes</h1>
          <p className="text-secondary-500 mt-1">Gérez vos classes, filières et affectations</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setShowCreate(true)}
            className="bg-primary-600 text-white px-5 py-2.5 rounded-xl hover:bg-primary-700 font-medium transition-colors flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Nouvelle Classe
          </button>
          <button 
            onClick={() => setShowImport(true)}
            className="bg-white text-secondary-700 px-5 py-2.5 rounded-xl hover:bg-secondary-50 font-medium transition-colors border border-secondary-200 flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            Importer
          </button>
        </div>
      </div>

      {/* Classes List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 mb-6">
        {classes.map(cl => {
          const assignments = cl.assignments || [];
          
          return (
            <div 
              key={cl.id} 
              className={`bg-white rounded-xl shadow-card border border-secondary-100 overflow-hidden cursor-pointer transition-all hover:shadow-card-hover ${
                selectedClasse === cl.id ? 'ring-2 ring-primary-500 border-primary-200' : ''
              }`}
              onClick={() => selectClasse(cl.id)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                      <svg className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-secondary-800">{cl.nom}</h3>
                      <p className="text-sm text-secondary-500">{cl.code}</p>
                    </div>
                  </div>
                  <span className="bg-primary-100 text-primary-700 text-xs px-3 py-1 rounded-full font-medium">
                    {cl.etudiants?.length || 0} étudiants
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-secondary-50 rounded-lg p-3">
                    <p className="text-xs text-secondary-500">Filière</p>
                    <p className="text-sm font-medium text-secondary-800">{cl.filiere?.nom || 'N/A'}</p>
                  </div>
                  <div className="bg-secondary-50 rounded-lg p-3">
                    <p className="text-xs text-secondary-500">Niveau</p>
                    <p className="text-sm font-medium text-secondary-800">{cl.niveau?.nom || 'N/A'}</p>
                  </div>
                </div>
                
                {cl.matieres && cl.matieres.length > 0 && (
                  <div className="border-t border-secondary-100 pt-3 mb-3">
                    <p className="text-xs text-secondary-500 mb-2">Matières ({cl.matieres.length})</p>
                    <div className="flex flex-wrap gap-1.5">
                      {cl.matieres.slice(0, 4).map((m, i) => (
                        <span key={i} className="bg-primary-50 text-primary-700 text-xs px-2.5 py-1 rounded-lg font-medium">
                          {m.nom}
                        </span>
                      ))}
                      {cl.matieres.length > 4 && (
                        <span className="bg-secondary-100 text-secondary-600 text-xs px-2.5 py-1 rounded-lg">
                          +{cl.matieres.length - 4}
                        </span>
                      )}
                    </div>
                  </div>
                )}
                
                {assignments.length > 0 && (
                  <div className="border-t pt-3">
                    <span className="text-gray-500 text-sm">Professeurs/Matières:</span>
                    <div className="mt-2 space-y-1">
                      {assignments.map((a, i) => (
                        <div key={i} className="text-sm">
                          <span className="text-green-600 font-medium">{a.professeur?.nom} {a.professeur?.prenom}</span>
                          <span className="text-gray-500"> → </span>
                          <span className="text-purple-600">{a.matiere?.nom}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="mt-4 pt-4 border-t border-secondary-100">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setSelectedClasse(cl.id); setShowAssign(true); }}
                    className="text-primary-600 text-sm font-medium hover:text-primary-700 flex items-center gap-1"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                    </svg>
                    Assigner professeur/matière
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Students List */}
      {selectedClasse && etudiants.length > 0 && (
        <div className="bg-white rounded-xl shadow-card border border-secondary-100 overflow-hidden">
          <div className="px-6 py-4 bg-secondary-50 border-b border-secondary-100">
            <h2 className="text-lg font-semibold text-secondary-800">
              Étudiants - {classes.find(c => c.id === selectedClasse)?.nom}
            </h2>
            <p className="text-sm text-secondary-500">{etudiants.length} étudiant(s)</p>
          </div>
          <table className="w-full">
            <thead className="bg-secondary-50">
              <tr>
                <th className="p-4 text-left text-sm font-semibold text-secondary-600">CNE</th>
                <th className="p-4 text-left text-sm font-semibold text-secondary-600">Nom</th>
                <th className="p-4 text-left text-sm font-semibold text-secondary-600">Prénom</th>
                <th className="p-4 text-left text-sm font-semibold text-secondary-600">Email</th>
              </tr>
            </thead>
            <tbody>
              {etudiants.map(et => (
                <tr key={et.id} className="border-b border-secondary-100 hover:bg-secondary-50">
                  <td className="p-4 font-mono text-sm text-secondary-600">{et.cne}</td>
                  <td className="p-4 font-medium text-secondary-800">{et.nom}</td>
                  <td className="p-4 text-secondary-600">{et.prenom}</td>
                  <td className="p-4 text-secondary-500">{et.email}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Assign Modal */}
      {showAssign && selectedClasse && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-soft p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-secondary-800 mb-2">Assigner professeur et matière</h2>
            <p className="text-sm text-secondary-500 mb-6">
              Classe: {classes.find(c => c.id === selectedClasse)?.nom}
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-2">Professeur</label>
                <select
                  value={assignProfessorId}
                  onChange={(e) => setAssignProfessorId(e.target.value)}
                  className="w-full border border-secondary-200 rounded-xl p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="">Sélectionner...</option>
                  {professeurs.map(p => (
                    <option key={p.id} value={p.id}>{p.nom} {p.prenom}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-2">Matière</label>
                <select
                  value={assignMatiereId}
                  onChange={(e) => setAssignMatiereId(e.target.value)}
                  className="w-full border border-secondary-200 rounded-xl p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="">Sélectionner...</option>
                  {matieres.slice(0, 20).map(m => (
                    <option key={m.id} value={m.id}>{m.nom}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => { setShowAssign(false); setAssignProfessorId(''); setAssignMatiereId(''); }}
                className="flex-1 bg-secondary-100 text-secondary-700 py-3 rounded-xl hover:bg-secondary-200 font-medium transition-colors"
              >
                Annuler
              </button>
              <button 
                onClick={() => handleAssign(selectedClasse)}
                className="flex-1 bg-primary-600 text-white py-3 rounded-xl hover:bg-primary-700 font-medium transition-colors"
              >
                Assigner
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}