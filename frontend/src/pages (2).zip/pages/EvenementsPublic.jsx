import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

export default function EvenementsPublic() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      console.log('Chargement événements...');
      const res = await api.get('/public/events');
      console.log('Événements reçus:', res.data);
      setEvents(res.data);
    } catch (err) {
      console.error('Erreur:', err);
      console.error('Réponse:', err.response);
      setError(err.message || 'Erreur lors du chargement des événements');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isPast = (date) => {
    return new Date(date) < new Date();
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">Événements</h1>
              <p className="text-purple-200 mt-1">Découvrez les événements du BTS Taza</p>
            </div>
            <div className="flex gap-3">
              <Link to="/inscription" className="px-4 py-2 bg-white text-purple-600 rounded-lg font-medium hover:bg-purple-50">
                S'inscrire pour participer
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        {events.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-8xl mb-4">📅</div>
            <h2 className="text-2xl font-semibold text-gray-700">Aucun événement prévu</h2>
            <p className="text-gray-500 mt-2">Revenez bientôt pour découvrir nos événements</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((event) => {
              const past = isPast(event.date_evenement);
              return (
                <div key={event.id} className={`bg-white rounded-xl shadow-sm border overflow-hidden ${past ? 'opacity-60' : ''}`}>
                  {event.image ? (
                    <div className="h-48 bg-cover bg-center" style={{ backgroundImage: `url(/storage/${event.image})` }}></div>
                  ) : (
                    <div className="h-48 bg-gradient-to-br from-purple-100 to-indigo-100 flex items-center justify-center">
                      <span className="text-6xl">🎉</span>
                    </div>
                  )}
                  
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-3">
                      {past ? (
                        <span className="text-sm bg-gray-100 text-gray-600 px-2 py-1 rounded">Passé</span>
                      ) : (
                        <span className="text-sm bg-green-100 text-green-700 px-2 py-1 rounded">À venir</span>
                      )}
                      {event.categorie && (
                        <span className="text-sm bg-purple-100 text-purple-700 px-2 py-1 rounded">
                          {event.categorie}
                        </span>
                      )}
                      {event.club && (
                        <span className="text-sm bg-blue-100 text-blue-700 px-2 py-1 rounded">
                          {event.club.nom}
                        </span>
                      )}
                    </div>
                    
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{event.titre}</h3>
                    
                    {event.description && (
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">{event.description}</p>
                    )}
                    
                    <div className="space-y-2 text-sm text-gray-500 mb-4">
                      <p className="flex items-center gap-2">
                        <span className="text-lg">📅</span> 
                        <span className={past ? 'text-gray-400' : ''}>{formatDate(event.date_evenement)}</span>
                      </p>
                      <p className="flex items-center gap-2">
                        <span className="text-lg">📍</span> {event.lieu}
                      </p>
                      {event.max_participants && (
                        <p className="flex items-center gap-2">
                          <span className="text-lg">👥</span> 
                          {event.max_participants} places disponibles
                        </p>
                      )}
                    </div>
                    
                    <div className="pt-4 border-t">
                      {past ? (
                        <button disabled className="w-full bg-gray-100 text-gray-400 py-2 rounded cursor-not-allowed">
                          Événement terminé
                        </button>
                      ) : (
                        <Link to="/inscription" className="block text-center bg-purple-600 text-white py-2 rounded hover:bg-purple-700">
                          Connectez-vous pour vous inscrire
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}