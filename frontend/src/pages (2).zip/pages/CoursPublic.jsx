import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

export default function CoursPublic() {
  const [cours, setCours] = useState([]);
  const [filieres, setFilieres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedFiliere, setSelectedFiliere] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [coursRes, filieresRes] = await Promise.all([
        api.get('/public/cours'),
        api.get('/filieres')
      ]);
      setCours(coursRes.data);
      setFilieres(filieresRes.data);
    } catch (err) {
      console.error('Erreur:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredCours = selectedFiliere 
    ? cours.filter(c => c.classe?.filiere_id == selectedFiliere)
    : cours;

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-blue-800 text-white py-6">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Cours & Ressources</h1>
              <p className="text-blue-200">Téléchargement nécessite inscription</p>
            </div>
            <Link to="/inscription" className="px-4 py-2 bg-white text-blue-800 rounded-lg font-medium hover:bg-blue-50">
              S'inscrire pour télécharger
            </Link>
          </div>
        </div>
      </header>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex gap-4 items-center">
          <label className="text-gray-600">Filière:</label>
          <select 
            className="border rounded-lg px-4 py-2"
            value={selectedFiliere}
            onChange={(e) => setSelectedFiliere(e.target.value)}
          >
            <option value="">Toutes les filières</option>
            {filieres.map(f => (
              <option key={f.id} value={f.id}>{f.nom} ({f.code})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Cours Grid */}
      <div className="max-w-7xl mx-auto px-4 pb-12">
        {filteredCours.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <p className="text-xl">Aucun cours disponible</p>
            <p className="mt-2">Revenez plus tard</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCours.map((c) => (
              <div key={c.id} className="bg-white rounded-xl shadow-sm border p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">{c.titre}</h3>
                    <p className="text-sm text-gray-500">{c.matiere?.nom}</p>
                  </div>
                  <span className="text-2xl">📚</span>
                </div>
                
                <div className="space-y-2 text-sm text-gray-600 mb-4">
                  <p><span className="font-medium">Professeur:</span> {c.professeur?.nom} {c.professeur?.prenom}</p>
                  <p><span className="font-medium">Classe:</span> {c.classe?.nom}</p>
                  <p><span className="font-medium">Filière:</span> {c.classe?.filiere?.nom}</p>
                </div>

                {c.description && (
                  <p className="text-sm text-gray-500 mb-4 line-clamp-2">{c.description}</p>
                )}

                <div className="pt-4 border-t">
                  {c.fichier ? (
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-green-600 font-medium">✓ Document disponible</span>
                      <Link to="/inscription" className="text-sm text-blue-600 hover:underline">
                        Connectez-vous pour télécharger
                      </Link>
                    </div>
                  ) : (
                    <span className="text-sm text-gray-400">Bientôt disponible</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}